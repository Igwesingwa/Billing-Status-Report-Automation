

Select cd.BusinessUnitName, cd.ServiceUnitName, p.CreatedDate, p.AccountNo as PmtAccountNumber, cd.TariffClassName, mc.CustomerType,  P.PaidAmount*mp.AmountEffect AS PaidAmount
from dbo.Tbl_CustomerPayments as P
inner join dbo.Tbl_MPaymentType as mp on mp.PaymentTypeID = p.PaymentType
inner join dbo.UDV_CustomerDescription as cd on cd.GlobalAccountNumber = p.AccountNo
inner join dbo.Tbl_MCustomerTypes as mc on mc.CustomerTypeId = cd.CustomerTypeId
where p.createdDate between '2022-09-01' and '2022-10-01'