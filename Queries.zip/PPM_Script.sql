Select cs.TariffDescription as TariffClassName,
cs.TariffIndex,
	cs.MeterNumber,
cs.BusinessUnitName,
cs.ServiceUnitName


--REPLACE(ServiceServiceUnit,'SERVICE UNIT',''),


--CASE WHEN cs.ServiceBusinessUnit IS NULL THEN cs.BusinessUnitName ELSE cs.ServiceBusinessUnit END AS newBusinessUnitName,

--CASE WHEN cs.ServiceServiceUnit IS NULL THEN cs.ServiceUnitName ELSE cs.ServiceServiceUnit END AS newServiceUnitName

--CASE WHEN cs.ServiceServiceUnit = "Agbor Main Office" THEN "AGBOR" ELSE cs.ServiceServiceUnit END AS ServiceUnitName

from CustomerSummary as cs