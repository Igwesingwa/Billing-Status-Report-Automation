Select Al.VendingNo as MeterNumber,
'Active' as DisplayCode,
      'PPM' as CustomerType,
	  Al.PaymentAmount as PaidAmount,
	    Al.Units as Energy_Billed,
		Al.PaymentAmount as BilledAmount,
		Al.CostOfUnits as Revenue_Billed


from AllTransactions as Al
WHERE Month(TransactionDateTime) = 09 and year(TransactionDateTime) = 2022

--group by VendingNo