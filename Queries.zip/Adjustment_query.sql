SELECT  CD.BusinessUnitName, CD.ServiceUnitName,mc.CustomerType, CD.TariffClassName, ADJ.AccountNo as AdjustmentAccountNumber, ADJ.CreatedDate, ADJ.AmountEffected FROM Tbl_BillAdjustments AS ADJ WITH (NOLOCK)
INNER JOIN UDV_CustomerDescription AS CD WITH (NOLOCK) ON CD.GlobalAccountNumber = ADJ.AccountNo
inner join Tbl_MCustomerTypes as mc with (nolock) on Mc.CustomerTypeId = cd.CustomerTypeId
WHERE  1 = 1 AND year(ADJ.CreatedDate) = '2022' AND month(ADJ.CreatedDate) = '09'

--BETWEEN '2022-09-01' AND '2022-01-12'