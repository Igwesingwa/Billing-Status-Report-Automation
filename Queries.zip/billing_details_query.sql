DECLARE @BillMonth INT, @BillYear INT, @MonthName VARCHAR(3);
SET @BillMonth = 9;
SET @BillYear = 2022;
SET @MonthName = dbo.fn_GetMonthName(@BillMonth);
WITH PoleDescription
     AS (SELECT PD.PoleId AS FeederTeamPoleId, 
                PD.Name AS PoleName, 
                M.ID AS FeederTeamId, 
                ISNULL(M.FirstName, '') + ' ' + ISNULL(M.LastName, '') AS MarketerName, 
                PD.PoleMasterId
         FROM dbo.Tbl_PoleDescriptionTable AS PD WITH(NOLOCK)
              LEFT JOIN dbo.Tbl_PoleFeederTeamMapping AS PT WITH(NOLOCK) ON PD.PoleId = PT.PoleId
              LEFT JOIN dbo.Tbl_FeederTeam AS M WITH(NOLOCK) ON PT.FeederTeamId = M.Id)
     SELECT BB.BusinessUnitName, 
            SU.ServiceUnitName, 
            CS.GlobalAccountNumber,   
            CT.CustomerType AS CustomerType, 
            CB.MeterNumber, 
            C.DisplayCode, 
            TC.TariffClassName, 
            CB.TariffRates, 
            CB.Usage AS Energy_Billed, 
            CB.NetEnergyCharges AS Revenue_Billed, 
            CB.TotalBillAmountWithTax AS BilledAmount, 
            CB.PreviousBalance AS Opening_Balance,  
            CB.TotalBillAmountWithArrears AS Closing_Balance

     FROM Tbl_CustomerBills AS CB WITH(NOLOCK)
          INNER JOIN CUSTOMERS.Tbl_CustomersDetail AS CS WITH(NOLOCK) ON CB.AccountNo = Cs.GlobalAccountNumber
          INNER JOIN CUSTOMERS.Tbl_CustomerProceduralDetails AS CPD WITH(NOLOCK) ON Cs.GlobalAccountNumber = CPD.GlobalAccountNumber
          INNER JOIN Tbl_BookNumbers AS BN WITH(NOLOCK) ON CPD.BookNumber = BN.BookNumber
          INNER JOIN Tbl_BookGroup AS BG WITH(NOLOCK) ON BN.BookGroupId = BG.BookGroupId
          INNER JOIN Tbl_ServiceCenter AS SC WITH(NOLOCK) ON BG.ServiceCenterId = SC.ServiceCenterId
          INNER JOIN Tbl_ServiceUnits AS SU WITH(NOLOCK) ON SC.ServiceUnitId = SU.ServiceUnitId
          INNER JOIN TBL_BUSSINESSUNITS AS BB WITH(NOLOCK) ON SU.BusinessUnitId = BB.BusinessUnitId
          INNER JOIN Tbl_States AS S WITH(NOLOCK) ON S.StateId = BB.StateId
          INNER JOIN Tbl_MReadCodes AS C WITH(NOLOCK) ON C.ReadCodeId = CB.ReadCodeId
          INNER JOIN Tbl_MTariffClasses AS TC WITH(NOLOCK) ON TC.TariffClassID = CB.TariffClassID
          INNER JOIN Tbl_MCustomerTypes AS CT WITH(NOLOCK) ON CT.CustomerTypeId = CPD.CustomerTypeId
          INNER JOIN UDV_USerDefinedValueDetails AS CD WITH(NOLOCK) ON CB.AccountNo = CD.GlobalAccountNumber
          INNER JOIN MASTERS.Tbl_MClusterCategories AS CC WITH(NOLOCK) ON CC.ClusterCategoryId = CPD.ClusterCategoryId
          LEFT JOIN PoleDescription AS PD1 ON CPD.Feeder33 = PD1.FeederTeamPoleId
                                              AND PD1.PoleMasterId = 3
          LEFT JOIN PoleDescription AS PD2 ON CPD.Feeder11 = PD2.FeederTeamPoleId
                                              AND PD2.PoleMasterId = 6
          LEFT JOIN PoleDescription AS PD3 ON CPD.DistributionTransformerId = PD3.FeederTeamPoleId
                                              AND PD3.PoleMasterId = 7
          LEFT JOIN UDV_CustomerMapping(NOLOCK) CM ON CM.GlobalAccountNumber COLLATE DATABASE_DEFAULT = CB.AccountNo
          LEFT JOIN dbo.Tbl_PoleDescriptionTable AS UPD WITH(NOLOCK) ON CM.DSSPoleId = UPD.PoleId
          LEFT JOIN dbo.Tbl_PoleFeederTeamMapping AS UPT WITH(NOLOCK) ON CM.DSSPoleId = UPT.PoleId
          LEFT JOIN dbo.Tbl_FeederTeam AS UM WITH(NOLOCK) ON UPT.FeederTeamId = UM.Id
     WHERE CB.BillYear = @BillYear
           AND CB.BillMonth IN(@BillMonth)
           --and  CS.GlobalAccountNumber in ()
           --and BB.BusinessUnitName in ('obiaruku')
           --and  CT.CustomerType in ('md')
           ;